package com.example.consumer.models;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Source {
	@JsonProperty
	public String product;
	 @JsonProperty(required=true)
    public String complaint_what_happened;
	 @JsonProperty(required=true)
    public Date date_sent_to_company;
	 @JsonProperty(required=true)
    public String issue;
	 @JsonProperty(required=true)
    public String sub_product;
	 @JsonProperty(required=true)
    public String zip_code;
	 @JsonProperty(required=true)
    public Object tags;
	 @JsonProperty(required=true)
    public String complaint_id;
	 @JsonProperty(required=true)
    public String timely;
	 @JsonProperty(required=true)
    public String consumer_consent_provided;
	 @JsonProperty(required=true)
    public String company_response;
	 @JsonProperty(required=true)
    public String submitted_via;
	 @JsonProperty(required=true)
    public String company;
	 @JsonProperty(required=true)
    public Date date_received;
	 @JsonProperty(required=true)
    public String state;
	 @JsonProperty(required=true)
    public String consumer_disputed;
	 @JsonProperty(required=true)
    public String company_public_response;
	 @JsonProperty(required=true)
    public String sub_issue;
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getComplaint_what_happened() {
		return complaint_what_happened;
	}
	public void setComplaint_what_happened(String complaint_what_happened) {
		this.complaint_what_happened = complaint_what_happened;
	}
	public Date getDate_sent_to_company() {
		return date_sent_to_company;
	}
	public void setDate_sent_to_company(Date date_sent_to_company) {
		this.date_sent_to_company = date_sent_to_company;
	}
	public String getIssue() {
		return issue;
	}
	public void setIssue(String issue) {
		this.issue = issue;
	}
	public String getSub_product() {
		return sub_product;
	}
	public void setSub_product(String sub_product) {
		this.sub_product = sub_product;
	}
	public String getZip_code() {
		return zip_code;
	}
	public void setZip_code(String zip_code) {
		this.zip_code = zip_code;
	}
	public Object getTags() {
		return tags;
	}
	public void setTags(Object tags) {
		this.tags = tags;
	}
	public String getComplaint_id() {
		return complaint_id;
	}
	public void setComplaint_id(String complaint_id) {
		this.complaint_id = complaint_id;
	}
	public String getTimely() {
		return timely;
	}
	public void setTimely(String timely) {
		this.timely = timely;
	}
	public String getConsumer_consent_provided() {
		return consumer_consent_provided;
	}
	public void setConsumer_consent_provided(String consumer_consent_provided) {
		this.consumer_consent_provided = consumer_consent_provided;
	}
	public String getCompany_response() {
		return company_response;
	}
	public void setCompany_response(String company_response) {
		this.company_response = company_response;
	}
	public String getSubmitted_via() {
		return submitted_via;
	}
	public void setSubmitted_via(String submitted_via) {
		this.submitted_via = submitted_via;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public Date getDate_received() {
		return date_received;
	}
	public void setDate_received(Date date_received) {
		this.date_received = date_received;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getConsumer_disputed() {
		return consumer_disputed;
	}
	public void setConsumer_disputed(String consumer_disputed) {
		this.consumer_disputed = consumer_disputed;
	}
	public String getCompany_public_response() {
		return company_public_response;
	}
	public void setCompany_public_response(String company_public_response) {
		this.company_public_response = company_public_response;
	}
	public String getSub_issue() {
		return sub_issue;
	}
	public void setSub_issue(String sub_issue) {
		this.sub_issue = sub_issue;
	}
    
    

}
