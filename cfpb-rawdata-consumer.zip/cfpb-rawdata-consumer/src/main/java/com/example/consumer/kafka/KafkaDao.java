package com.example.consumer.kafka;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.*;
import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONArray;
import org.json.JSONObject;

import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import com.example.consumer.models.Complaints;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

import io.confluent.kafka.schemaregistry.client.CachedSchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import io.confluent.kafka.schemaregistry.json.JsonSchema;
import io.confluent.kafka.schemaregistry.json.JsonSchemaUtils;
import io.confluent.kafka.serializers.json.KafkaJsonSchemaSerializerConfig;

import java.io.*;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;

@Component
public class KafkaDao {

	
	
public void consumeMessages() {
	Gson gson = new Gson();
	ObjectMapper mapper = new ObjectMapper();
	 String json;
	 JSONParser parser = new JSONParser();
	
	
	Properties consumerprops = new Properties();
	//String username="6NH2KBZXGGFYALJH";
	//String password="23iLX8SMnNIS5J/fHsJlKqmVXbMN251qDZKluq2+s0o/PcKOWLpPYkddvbN72bt/";
	String usernames="57GSQ34SAKZRY3I4";
	String passwords="kK3n1qcji7ZBqVe9rwyRsEuI037ZWaI2FfRhsI5aSJdjLOIGbba33j6d4IPvX5bs";
	consumerprops.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "pkc-4r087.us-west2.gcp.confluent.cloud:9092");
	consumerprops.put(ConsumerConfig.GROUP_ID_CONFIG, "cfpb_transformation");
	consumerprops.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
	consumerprops.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
	consumerprops.put("security.protocol", "SASL_SSL");
	consumerprops.put("sasl.jaas.config", "org.apache.kafka.common.security.plain.PlainLoginModule required username="+"'"+usernames+"'"+"password="+"'"+passwords+"'"+";");
	consumerprops.put("sasl.mechanism", "PLAIN");
	consumerprops.put("schema.registry.url", "https://psrc-xqq6z.us-central1.gcp.confluent.cloud");
	consumerprops.put("basic.auth.credentials.source", "USER_INFO");
	consumerprops.put("basic.auth.user.info", "55XRBEZAMIDNZ7ON:py6XkYOMGSWQ32ldUifdqlStrRQLMrf4dikaMDvnObpTxXreQCE9Wn/XSbFMtJGR");
	consumerprops.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
	consumerprops.put("client.id", "cfpb-complaints-transformer-api");
	

	Properties producerprops = new Properties();
	producerprops.put("bootstrap.servers", "pkc-4r087.us-west2.gcp.confluent.cloud:9092");
	producerprops.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
	producerprops.put("value.serializer", "io.confluent.kafka.serializers.json.KafkaJsonSchemaSerializer");
	producerprops.put("security.protocol", "SASL_SSL");
	producerprops.put("sasl.jaas.config", "org.apache.kafka.common.security.plain.PlainLoginModule required username="+"'"+usernames+"'"+"password="+"'"+passwords+"'"+";");
	producerprops.put("sasl.mechanism", "PLAIN");
	producerprops.put("client.dns.lookup", "use_all_dns_ips");
	producerprops.put("session.timeout.ms", "45000");
	producerprops.put("schema.registry.url", "https://psrc-xqq6z.us-central1.gcp.confluent.cloud");
	producerprops.put("basic.auth.credentials.source", "USER_INFO");
	producerprops.put("basic.auth.user.info", "55XRBEZAMIDNZ7ON:py6XkYOMGSWQ32ldUifdqlStrRQLMrf4dikaMDvnObpTxXreQCE9Wn/XSbFMtJGR");
	producerprops.put("auto.register.schemas", false);
	producerprops.put("use.latest.version", true);
	producerprops.put("json.fail.invalid.schema", true);
	//producerprops.put("value.schema.id", "100002");
	producerprops.put("confluent.value.schema.validation", true);
	producerprops.put("acks", "all");
	producerprops.put("client.id", "cfpb-complaints-transformer-api");
	
	
	KafkaConsumer<String, String> consumer = new KafkaConsumer<>(consumerprops);
	consumer.subscribe(Arrays.asList("cfpb-complaints"));
	
	
	/*schemaRegistryClient = new CachedSchemaRegistryClient("https://psrc-vn38j.us-east-2.aws.confluent.cloud", 30);
    System.out.println(schemaRegistryClient);
    try {
		//SchemaMetadata schemaMetadata=schemaRegistryClient.getLatestSchemaMetadata("cfpbrealtime");
		//String schemafrom =schemaMetadata.getSchema();
		//System.out.println("schemafrom=>"+ schemafrom);
		//Optional<ParsedSchema> schema=schemaRegistryClient.parseSchema(schemaMetadata.getSchemaType(), schemaMetadata.getSchema(), schemaMetadata.getReferences());
		//schema = (JsonSchema)
	} catch (IOException | RestClientException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}*/
	 
  
	Producer<String, JsonNode> producer = new KafkaProducer<>(producerprops);
	
	
	try {
	while (true) {
		 try {
			
			ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(5000));
			 for (ConsumerRecord<String, String> record : records) {
			       // System.out.println("key = %s, value = %s%n"+ record.key()+ record.value());
					try {
						// JSONObject
						//json = mapper.writeValueAsString(record.value());
						JSONObject jsonobj = new JSONObject(record.value());  
						String key=jsonobj.getString("_id");
						System.out.println("message consumed from  Input Topic==>"+ jsonobj.toString());
						System.out.println("key==>"+ key);
					//	producer.send(new ProducerRecord<>("cfpbrealtime-derived", jsonobj));//Found incompatible change: Difference{jsonPath='#/properties/_index', type=PROPERTY_ADDED_TO_OPEN_CONTENT_MODEL}
						
						
						// POJO
						/*Complaints complaints = mapper.readValue(json, Complaints.class);
						System.out.println("Complaint ids==>"+ complaints.get_id());
						producer.send(new ProducerRecord<>("cfpbrealtime-derived", complaints));//Found incompatible change: Difference{jsonPath='#/properties/_index', type=TYPE_CHANGED}
						 */
						
						JsonNode payload = mapper.readTree(jsonobj.toString());
						 try(InputStream in=Thread.currentThread().getContextClassLoader().getResourceAsStream("schema.json")){
							    JsonNode schema = mapper.readValue(in, JsonNode.class);
							    String schemaString = mapper.writeValueAsString(schema);
							    System.out.println(schemaString);
							    producer.send(new ProducerRecord<>("cfpb-complaints-derived", key,JsonSchemaUtils.envelope(schema,payload)));;
							}catch (ValidationException  e) {
					            List<String> messages = e.getAllMessages();
					            // Print the messages
					            for (String message : messages) {
					                System.out.println(message);
					            }
							}
							 catch (ConstraintViolationException  e) {
								 e.getConstraintViolations().forEach(v -> System.out.println(v.getMessage()));
								}
							catch(Exception e){
							throw new RuntimeException(e);
								//e.printStackTrace();
							}
						
						
					} 
					 catch (Exception  e) {
						 e.printStackTrace();
						}
			        
			        	
			      
			    }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			 System.out.println(e.getClass());
			e.printStackTrace();
		}
		 System.out.println("consumer Running");
		}
	}
	finally {
		producer.flush();
		producer.close();
		consumer.close();
		}
	 
}

}