package com.example.consumer.models;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Complaints {
	 @JsonProperty(required=true)
	 public String _index;
	 
	 @JsonProperty(required=true)
	    public String _type;
	 @JsonProperty(required=true)
	    public String _id;
	 @JsonProperty(required = true)
	    public Object _score;
	 @JsonProperty(required=true)
	    public Source _source;
	 @JsonProperty(required=true)
	    public ArrayList sort;
	    
		public String get_index() {
			return _index;
		}
		public void set_index(String _index) {
			this._index = _index;
		}
		public String get_type() {
			return _type;
		}
		public void set_type(String _type) {
			this._type = _type;
		}
		public String get_id() {
			return _id;
		}
		public void set_id(String _id) {
			this._id = _id;
		}
		public Object get_score() {
			return _score;
		}
		public void set_score(Object _score) {
			this._score = _score;
		}
		public Source get_source() {
			return _source;
		}
		public void set_source(Source _source) {
			this._source = _source;
		}
		public ArrayList getSort() {
			return sort;
		}
		public void setSort(ArrayList sort) {
			this.sort = sort;
		}
	   
	    

}
