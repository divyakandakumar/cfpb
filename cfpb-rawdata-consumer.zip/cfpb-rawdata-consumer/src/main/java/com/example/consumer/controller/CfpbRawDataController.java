package com.example.consumer.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.consumer.kafka.KafkaDao;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import sun.net.www.protocol.http.HttpURLConnection;

@RestController
@RequestMapping("/api/v1")
public class CfpbRawDataController {

	@Autowired
	KafkaDao kafkadao;

	
	@GetMapping("/health")
	public String checkHealth() {
		return "I am working fine now 1222";
		
	}
	
	@RequestMapping(value = "/cfpbread")
	   public void getCFPBRawData() {
		kafkadao.consumeMessages();
	   }
	
}
