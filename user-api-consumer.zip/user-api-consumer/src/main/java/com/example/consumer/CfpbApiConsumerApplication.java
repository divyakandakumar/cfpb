package com.example.consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.example.consumer.controller.Controller;

@SpringBootApplication
@EnableScheduling
public class CfpbApiConsumerApplication {
	
	@Autowired
	Controller controller;

	public static void main(String[] args) {
		SpringApplication.run(CfpbApiConsumerApplication.class, args);
		
	}
	
	// @Scheduled(cron = "0 0/30 * * * ?")
	  //  public void run() {
	    //    controller.getComplaints();
	  //  }


	
}
