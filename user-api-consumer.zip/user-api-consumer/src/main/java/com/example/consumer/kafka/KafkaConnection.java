package com.example.consumer.kafka;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.*;

import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONArray;
import org.json.JSONObject;
//import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.module.jsonSchema.JsonSchemaGenerator;
import com.google.gson.Gson;
import com.kjetland.jackson.jsonSchema.JsonSchemaConfig;
import com.kjetland.jackson.jsonSchema.JsonSchemaDraft;

import io.confluent.kafka.schemaregistry.ParsedSchema;
import io.confluent.kafka.schemaregistry.client.CachedSchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.SchemaMetadata;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.rest.exceptions.RestClientException;
import io.confluent.kafka.schemaregistry.json.JsonSchema;
import io.confluent.kafka.schemaregistry.json.JsonSchemaUtils;

import java.io.*;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;

@Component
public class KafkaConnection {


	
	public void sendmessages(String response) {
		
		//CFPB service account
		String username="57GSQ34SAKZRY3I4";
		String password="kK3n1qcji7ZBqVe9rwyRsEuI037ZWaI2FfRhsI5aSJdjLOIGbba33j6d4IPvX5bs";
		
        
		Properties props = new Properties();
		props.put("bootstrap.servers", "pkc-4r087.us-west2.gcp.confluent.cloud:9092");
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		//props.put("value.serializer", "org.springframework.kafka.support.serializer.JsonSerializer");	
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");	
		props.put("security.protocol", "SASL_SSL");
		props.put("sasl.jaas.config", "org.apache.kafka.common.security.plain.PlainLoginModule required username="+"'"+username+"'"+"password="+"'"+password+"'"+";");
		props.put("sasl.mechanism", "PLAIN");
		props.put("client.dns.lookup", "use_all_dns_ips");
		props.put("session.timeout.ms", "45000");
		props.put("client.id", "cfpb-complaints-api");
		
		//Schema  validation not needed for input topic
		//props.put("schema.registry.url", "https://psrc-vn38j.us-east-2.aws.confluent.cloud");
		//props.put("basic.auth.credentials.source", "USER_INFO");
		//props.put("basic.auth.user.info", "43JFIYG5MFQKE2MJ:yu+VKg3M2JOaICFiv4C+jR88pnSKf38tkWD//xjVnwmkmaWgdurv0lVPO3WtMyxn");
		//props.put("auto.register.schemas", false);
		//props.put("use.latest.version", true);
	//	props.put("json.fail.invalid.schema", true);
	//	props.put("confluent.value.schema.validation", true);
	//	props.put("acks", "all");
		
	
		
		
		Producer<String, String> producer = new KafkaProducer<>(props);
		JSONArray jsonarray = new JSONArray(response);
		 for (int i = 0; i < jsonarray.length(); i++) {
		    JSONObject jsonobject = jsonarray.getJSONObject(i);
		    String key=jsonobject.getString("_id");
		    System.out.println("JSON-==>"+jsonobject);
		    
		    if(key != null && key.trim().length() > 0){
		    	producer.send(new ProducerRecord<>("cfpb-complaints", key,jsonobject.toString()));
		    }
		 }
		producer.flush();
		producer.close();
		
}

}