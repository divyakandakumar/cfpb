package com.example.consumer.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.consumer.kafka.KafkaConnection;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import sun.net.www.protocol.http.HttpURLConnection;

@RestController
@RequestMapping("/api/v1")
public class Controller {

	private static final String URL_1 = "https://www.consumerfinance.gov/data-research/consumer-complaints/search/api/v1/";
	
	
	@Autowired
	KafkaConnection kafkaConnection;

	@Autowired
	Gson gson;

	
	@RequestMapping(value = "/cfpb")
	   public void getComplaints() {
		String todaydate=getCurrentDate();
		String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date());
		//String[] banklist = {"CITIBANK, N.A.", "AMERICAN EXPRESS COMPANY", "JPMORGAN CHASE & CO."};
		String[] banklist = {"CITIBANK, N.A."};
		//System.out.println("todaydate==>"+todaydate + timeStamp);
		for (String bank : banklist){
			System.out.println("bank==>"+bank);
			 String response = null;
			String urlTemplate = UriComponentsBuilder.fromHttpUrl(URL_1)
					.queryParam("size", "20000")
			        .queryParam("format", "json")
			        .queryParam("company", bank)
			        .queryParam("date_received_max", todaydate)
			        .queryParam("date_received_min", "2023-05-01")
			        .encode()
			        .toUriString();
			
			try {
				URL obj=new URL(urlTemplate);
				
					HttpsURLConnection con=(HttpsURLConnection)obj.openConnection();
				con.connect();
				 response=handleresponse(con);
				 
				 System.out.println("response==>"+response);
				kafkaConnection.sendmessages(response.toString());
					
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	   
		//return response;
	   }
	
	/*
	 * @RequestMapping(value = "/cfpbread") public void getCFPBRawData() {
	 * kafkaConnection.consumeMessages(); }
	 */
	
	public  String handleresponse(HttpsURLConnection con)throws IOException{
		int responsecode=con.getResponseCode();
		
		InputStream is = con.getInputStream();
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder result = new StringBuilder();
		String line;
		while((line = reader.readLine()) != null) {
		    result.append(line);
		}
		System.out.println(result.toString());
		return result.toString();
	}
	
	public String getCurrentDate() {
		String currentdate=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        System.out.println(dateFormat.format(date));
        currentdate=dateFormat.format(date);
		return currentdate;
	}
	
}
